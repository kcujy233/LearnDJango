from django.apps import AppConfig


class CrawlerAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "crawler_app"
